rootPath = '~/Dropbox/jatos/workshop_ASSC/examples/neglect';
dataPath = [rootPath filesep 'jatosResults'];

addpath(genpath([rootPath filesep 'analysis/jsonlab-1.5']))
addpath(rootPath)

dataFiles = dir([dataPath, filesep, '*.txt']);

for subj = 1:length(dataFiles)
  resultData = loadjson([dataPath, filesep, dataFiles(subj).name]);
  %Remove the first 31 characters: "\"imgData=data:image/png;base64,"
  %And the last 3 characters: \""
  textToConvert = resultData{1}.image_data(32:end-3);
  
  %Save image
  base64decode(textToConvert, [dataPath filesep 'subj_' num2str(subj) 'clock_Matlab.png']);

end


