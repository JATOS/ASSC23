The following people have contributed to the development of jsPsych by writing code, documentation, and/or suggesting improvements (in alphabetical order):
* Xiaolu Bai - https://github.com/lbai001
* Jason Carpenter
* Steve Chao - https://github.com/stchao
* Jana Klaus - https://github.com/janakl4us
* Jonas Lambers
* Shane Martin - https://github.com/shamrt
* Adrian Oesch - https://github.com/adrianoesch
* Junyan Qi - https://github.com/GavinQ1
* Dan Rivas - https://github.com/rivasd
* Marian Sauter - https://github.com/mariansauter
* Tim Vergenz - https://github.com/vergenzt
* Matteo Visconti di Oleggio Castello - https://github.com/mvdoc
* Wolfgang Walther - https://github.com/wolfgangwalther
* Erik Weitnauer - https://github.com/eweitnauer
* Rob Wilkinson - https://github.com/RobAWilkinson
